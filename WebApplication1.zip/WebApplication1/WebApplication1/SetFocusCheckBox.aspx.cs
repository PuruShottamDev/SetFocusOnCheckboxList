﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData();
            }
        }

        private void BindData()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Id");
            dt.Columns.Add("Name");
            for (int i = 0; i < 30; i++)
            {
                dt.Rows.Add(i.ToString(), "A" + i.ToString());
            }
            chkList.DataSource = dt;
            chkList.DataValueField = "Id";
            chkList.DataTextField = "Name";
            chkList.DataBind();
        }


        protected void chkList_OnSelectedIndexChanged(object sender, EventArgs e)
        {

            string sScript = "SetFocus('" + chkList.ClientID + "_" + chkList.SelectedIndex.ToString() + "');";

            ScriptManager.RegisterClientScriptBlock(this, typeof(System.Web.UI.Page), "focusScript", sScript, true);

        }

    }
}
